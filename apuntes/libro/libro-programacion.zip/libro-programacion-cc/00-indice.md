# Índice

**Parte I. Entender el lenguaje y sus valores**

- [Capítulo 1. Del problema al programa](parte-1-entender-el-lenguaje-y-sus-valores/01-del-problema-al-programa.md)
- [Capítulo 2. Variables, alcance y expresiones](parte-1-entender-el-lenguaje-y-sus-valores/02-variables-alcance-y-expresiones.md)
- [Capítulo 3. El tipo `boolean`](parte-1-entender-el-lenguaje-y-sus-valores/03-el-tipo-boolean.md)
- [Capítulo 4. Los tipos `number` y `bigint`](parte-1-entender-el-lenguaje-y-sus-valores/04-number-y-bigint.md)
- [Capítulo 5. El tipo `string` y Unicode](parte-1-entender-el-lenguaje-y-sus-valores/05-string-y-unicode.md)
- [Capítulo 6. `undefined`, `null` y la ausencia de datos](parte-1-entender-el-lenguaje-y-sus-valores/06-undefined-null-y-ausencia.md)
- [Capítulo 7. Conversión y coerción de tipos](parte-1-entender-el-lenguaje-y-sus-valores/07-conversion-y-coercion.md)
- [Capítulo 8. El tipo `symbol` y los protocolos del lenguaje](parte-1-entender-el-lenguaje-y-sus-valores/08-symbol-y-protocolos.md)

**Parte II. Modelar colecciones y entidades**

- [Capítulo 9. Arrays y matrices](parte-2-modelar-colecciones-y-entidades/09-arrays-y-matrices.md)
- [Capítulo 10. Objetos, propiedades y referencias](parte-2-modelar-colecciones-y-entidades/10-objetos-y-referencias.md)
- [Capítulo 11. `Map`, `Set` y colecciones especializadas](parte-2-modelar-colecciones-y-entidades/11-map-set-y-colecciones.md)

**Parte III. Organizar el comportamiento**

- [Capítulo 12. Estructuras de control](parte-3-organizar-el-comportamiento/12-estructuras-de-control.md)
- [Capítulo 13. Errores y excepciones](parte-3-organizar-el-comportamiento/13-errores-y-excepciones.md)
- [Capítulo 14. Funciones](parte-3-organizar-el-comportamiento/14-funciones.md)
- [Capítulo 15. Programación funcional y pipelines de datos](parte-3-organizar-el-comportamiento/15-programacion-funcional-y-pipelines.md)
- [Capítulo 16. Recursividad y árboles binarios](parte-3-organizar-el-comportamiento/16-recursividad-y-arboles.md)

**Parte IV. Aplicar e integrar**

- [Capítulo 17. Programación asincrónica con `async` y `await`](parte-4-aplicar-e-integrar/17-programacion-asincronica.md)
- [Capítulo 18. Expresiones regulares](parte-4-aplicar-e-integrar/18-expresiones-regulares.md)
- [Capítulo 19. Gestión de archivos con Node.js](parte-4-aplicar-e-integrar/19-archivos-con-nodejs.md)

**Parte V. Construir para la Web**

- [Capítulo 20. Desarrollo web: del documento a una aplicación del clima](parte-5-construir-para-la-web/20-desarrollo-web.md)
- [Capítulo 21. Arrow.js: del contador al inventario](parte-5-construir-para-la-web/21-arrowjs.md)
- [Capítulo 22. Cómo consumir una API REST](parte-5-construir-para-la-web/22-consumir-api-rest.md)

**Apéndices**

- [Apéndice A. Byte Pair Encoding: construir un tokenizador](apendices/apendice-a-tokenizador-bpe.md)
- [Apéndice B. Evaluar expresiones mediante pilas](apendices/apendice-b-evaluar-expresiones.md)
- [Apéndice C. Fundamentos de computación digital](apendices/apendice-c-computacion-digital.md)
- [Apéndice D. Una agenda de terminal con React e Ink](apendices/apendice-d-agenda-con-ink-y-react.md)
- [Apéndice E. Referencia rápida de expresiones regulares](apendices/apendice-e-referencia-regex.md)
- [Apéndice F. Glosario](apendices/apendice-f-glosario.md)

**Material final**

- [Fuentes](99-fuentes.md)

---

Documento consolidado: [`libro-completo.md`](libro-completo.md)

Registro editorial: [informe](00-informe-editorial.md) · [mapa de fuentes](mapa-de-fuentes.md)
