# Informe editorial

Registro del trabajo de edición: qué se recibió, cómo se organizó, qué se
corrigió y qué decisiones se tomaron.

- **Edición:** Programación Web · Programación IV · TUP26
- **Autor:** Ing. Alejandro Di Battista
- **Idioma:** es-AR
- **Fuente:** carpeta `apuntes`, archivos `00` a `22`, apéndices y tapa

---

## 1. Material recibido

### Archivos 00: la edición según el autor

`00-indice.md` y `00-informe-editorial.md` no son capítulos: describen el libro.
Se usaron como metadatos.

- **Título, autor y tapa.** La tapa, `portada.jpg`, dice «Programación Web»,
  «Programación IV», «TUP26» e «Ing. Alejandro Di Battista». El informe del
  autor confirma el autor y el nombre de la edición. Con esos datos se
  completaron los metadatos del PDF y del EPUB, que en la edición anterior
  quedaban sin autor.
- **Partes.** `00-indice.md` agrupa los capítulos en cuatro partes con nombres
  propios. Se adoptaron.
- **Lo que no se incorporó.** El mismo índice incluye una tesis del libro, una
  descripción del método con que está escrito cada capítulo, rutas de lectura y
  un método de estudio. Todo eso explica cómo leer el libro, no su contenido, y
  quedó afuera. También estaba desactualizado en dos puntos: ubicaba los
  fundamentos de computación digital como capítulo 17 —hoy es la asincronía— y
  enlazaba `apendices/100-tokens.md`, que ya no existe con ese nombre.

### Capítulos 01 a 19: sin cambios desde la edición anterior

Los diecinueve archivos son idénticos, byte por byte, a los que se editaron en la
edición anterior; se comprobó con su huella MD5. Lo mismo ocurre con los cuatro
archivos de `apendices/` que forman los apéndices A a D. Todo el trabajo hecho
sobre ellos se conserva.

### Capítulos 20 a 22: la parte nueva

| Archivo | Tema | Palabras de prosa |
|---|---|---:|
| `20-desarrollo-web.md` | HTML, CSS, DOM, eventos, HTTP y una aplicación del clima | 6.700 |
| `21-arrowjs.md` | Interfaces reactivas con Arrow.js | 1.700 |
| `22-consumir-api-rest.md` | HTTP, REST, cURL, `fetch` y una aplicación de terminal con Ink | 3.400 |

El capítulo 20 es el más extenso del libro: su versión impresa ocupa 46 páginas.
Se conservó como una unidad porque así lo organizó el autor y porque su
recorrido —del documento a la aplicación— pierde sentido si se corta.

`21-arrowjs.html` es la versión HTML del capítulo 21, con los mismos títulos; se
usó la versión Markdown.

### Lo que quedó afuera

`apendices/130-tutorial-crud-ink-react.md` está fuera del rango `00` a `22` y no
formaba parte de la edición anterior. La carpeta `tutorial/` tampoco se usó.

### Extensión

Contadas sobre la prosa, sin bloques de código ni tablas:

| Bloque | Palabras |
|---|---:|
| Capítulos 1 a 19 | 22.500 |
| Capítulos 20 a 22 | 11.800 |
| Apéndices A a F | 11.300 |
| Total | 45.800 |

Con el código y las tablas incluidos, el documento maestro suma unas 72.000
palabras y 889 bloques de código.

---

## 2. Arquitectura

Cinco partes, veintidós capítulos, seis apéndices y una sección final de
fuentes.

**Parte I — Entender el lenguaje y sus valores (1–8).** El lenguaje, el motor y
el anfitrión; las variables y expresiones; y los siete tipos primitivos con sus
conversiones.

**Parte II — Modelar colecciones y entidades (9–11).** Arrays, objetos y las
colecciones especializadas.

**Parte III — Organizar el comportamiento (12–16).** Control del flujo, errores,
funciones, programación funcional y recursividad.

**Parte IV — Aplicar e integrar (17–19).** Asincronía, expresiones regulares y
archivos.

**Parte V — Construir para la Web (20–22).** Nueva. Su nombre sigue la forma de
los otros cuatro, que empiezan con un verbo. Los tres capítulos avanzan en
espiral: el 20 usa HTTP y `fetch` lo justo para construir una aplicación en el
navegador, el 21 cambia la forma de actualizar la interfaz y el 22 vuelve sobre
HTTP para desarmarlo por completo.

Los apéndices no cambiaron: A, tokenizador BPE; B, evaluador de expresiones; C,
computación digital; D, agenda de terminal con React e Ink; E, referencia de
regex; F, glosario.

**Fuentes** es material nuevo al final del libro. Reúne la lista de fuentes que
el capítulo 20 traía al cierre y los documentos que citan los capítulos 21 y 22 y
el apéndice D.

---

## 3. Edición de los capítulos nuevos

Los tres capítulos venían con otra estructura que el resto: secciones numeradas
por su cuenta, índice propio y sin «Idea central», «Errores frecuentes» ni «Para
recordar». Se llevaron a la forma del libro.

**Capítulo 20.**

- Se escribió la idea central y se convirtió el párrafo de requisitos previos en
  un enlace con los capítulos anteriores.
- Salieron del capítulo el índice interno, el glosario —sus diecinueve términos
  pasaron al apéndice F— y la lista de fuentes, que pasó a la sección final.
- La tabla de problemas frecuentes se integró en «Errores frecuentes», junto con
  once confusiones que el propio capítulo advierte en distintas secciones: el
  atributo `disabled="false"`, la especificidad leída como un número decimal,
  `innerHTML` con texto externo, `preventDefault` y la propagación, `mode:
  "no-cors"`, entre otras.
- Los cinco bloques de `app.js` conservan su número como nombre —«Bloque 1:
  referencias al DOM y estado»— en lugar de competir con la numeración de
  secciones.
- Una frase dirigida a quien enseña el proyecto se reescribió para quien lee.

**Capítulo 21.** La frase en negrita que lo abría pasó a ser la idea central. La
tabla con los seis pasos del recorrido describía la estructura del capítulo y se
quitó; el proyecto se sigue presentando en prosa.

**Capítulo 22.**

- La lista de contenidos inicial se reemplazó por la idea central.
- «Este apunte» pasó a ser «este capítulo», y las remisiones a «la sección 1»,
  a la sección 22.1.
- Los cuatro ejercicios finales pasaron a ser un párrafo expositivo, «Cómo se
  extiende», que conserva la información técnica que contenían: los parámetros
  `forecast_days` y `temperature_unit`, `ink-select-input` para elegir entre
  ciudades homónimas y `performance.now()` para medir.
- El resumen se repartió entre «Errores frecuentes», nuevo, y «Para recordar».

---

## 4. Integración

### Remisiones

Se agregaron veintiséis remisiones que conectan la parte V con el resto del
libro, en las dos direcciones. Algunas:

- de la validación de formularios, en 20.4, a la sección 1.5: la validación del
  navegador mejora la experiencia, la del servidor protege el sistema;
- de la sección 17.1, que presenta el modelo asincrónico, al ciclo de eventos de
  20.11, que muestra el orden exacto A, D, C, B;
- de la sutileza de `fetch` en 13.14 y 17.4 a la sección 22.8, que explica por
  qué ocurre a partir de cómo llega una respuesta HTTP;
- de las plantillas etiquetadas de 5.15 al capítulo 21, donde `html` es una;
- del apéndice D a los capítulos 21 y 22: el mismo enfoque declarativo con
  Arrow.js y el mismo Ink en otra aplicación.

El libro tiene ahora **309 remisiones internas**. Todas apuntan a una sección, un
capítulo o un apéndice que existe.

### Solapamientos

La parte V retoma temas que el libro ya desarrolló. En cada caso se conservó el
texto del capítulo nuevo, que los usa en su contexto, y se agregó la remisión al
desarrollo completo.

| Tema | Desarrollo | Aparece también en |
|---|---|---|
| Lenguaje, motor y anfitrión | 1.3 | 20.9 |
| Promesas, `async` y `await` | capítulo 17 | 20.11, 22.8 |
| `fetch` no rechaza con un 404 | 22.8 | 13.14, 17.4, 20.11 |
| JSON como formato | 22.4 | 10.18, 19.30, 20.11 |
| `Promise.all` | 17.6 | 22.8 |
| Ink | apéndice D | 22.9 |

Las dos funciones `pedirJSON`, la del capítulo 20 y la del 22, se conservaron: no
son la misma. La del 20 agrega un tiempo límite y traduce cada fallo a un mensaje
para la persona; la del 22 comprueba el tipo de contenido y trata el 204. La
sección 22.9 señala la relación.

### Glosario

El apéndice F pasó de 113 a **146 términos**: los del glosario del capítulo 20
más los de HTTP, REST y reactividad que introducen los capítulos 21 y 22.

---

## 5. Revisión técnica

Los servicios que usan los proyectos —Open-Meteo, JSONPlaceholder, la CDN de
Arrow.js— no son accesibles desde el entorno de verificación. Se simularon con
respuestas que reproducen su forma documentada, y el código se ejecutó completo.

| Qué se ejecutó | Cómo | Comprobaciones |
|---|---|---:|
| Aplicación del clima del capítulo 20 | Los tres archivos extraídos del texto, en Chromium, con Open-Meteo simulado: búsqueda, selección, consulta, 0 °C, formato `es-AR`, zona horaria, foco, error 429, sin resultados | 21 |
| Ejemplo del DOM, ciclo de eventos y modelo de caja del capítulo 20 | Chromium: `Object.hasOwn`, `preventDefault`, orden A, D, C, B, anchos 344 y 256 | 6 |
| Inventario del capítulo 21 | El archivo final completo, en Chromium, con Arrow.js 1.0.6 instalado desde npm: sumar, restar, deshabilitar, buscar, dar de alta, cancelar, eliminar homónimos | 26 |
| HTTP y `fetch` del capítulo 22 | Node.js contra un servidor que imita JSONPlaceholder: dos esperas, cuerpo leído una vez, 404 sin excepción, `pedirJSON`, `URL`, `Promise.all`, `Content-Length` | 21 |
| Aplicación de Ink del capítulo 22 | Instalada con el mismo `npm install` del texto e ink-testing-library, con Open-Meteo simulado: resultado completo, ciudad inexistente, error 500, contenido no JSON, entrada vacía | 19 |

Las **93 comprobaciones** pasan. Se suman a las 559 de la edición anterior, que
siguen valiendo porque los capítulos 1 a 19 y los apéndices no cambiaron.

### Correcciones

**La versión de Node.js del capítulo 22.** El texto pedía «Node.js 20 o
posterior» y luego instala `ink` sin fijar versión. Hoy eso instala Ink 7.1.1,
que declara como requisito Node.js 22. Se corrigió a 22, que es también lo que
pide el apéndice D.

**La respuesta de ejemplo de Open-Meteo, en 22.9.** El JSON mostrado no traía
`current_units.apparent_temperature` ni `daily_units`, y el código de la
aplicación lee los dos. Con la respuesta tal como estaba impresa, la aplicación
fallaría. Se agregaron ambos y se aclaró que la respuesta está recortada.

**El diagrama de la URL, en 22.1.** El corchete del host estaba corrido una
posición y abarcaba `pi.ejemplo.com:` en lugar de `api.ejemplo.com`; el del
esquema incluía los dos puntos. Se realineó.

**Una errata del capítulo 20.** «Cascada e herencia» y «especificidad e
herencia»: la conjunción pasa a «e» solo delante del sonido /i/, y «herencia»
empieza con /e/. Quedó «y».

### Lo que se revisó y estaba correcto

- La aplicación del clima muestra 0 °C como «0 °C» y no como «No disponible»,
  tal como afirma el texto, porque `Number.isFinite(0)` es verdadero.
- Filtra las ubicaciones sin coordenadas y oculta el resultado anterior al
  cambiar la selección.
- `Content-Length: 47` es exacto para el cuerpo de ejemplo: `é` ocupa dos bytes.
- Arrow.js 1.0.6 existe, es la versión actual y exporta `reactive`, `html` y
  `component`, con la ruta `dist/index.mjs` que usa el capítulo.
- `npm install ink react ink-text-input ink-spinner` resuelve sin conflictos de
  dependencias.

---

## 6. Decisiones de forma

**Tapa.** El PDF abre con `portada.jpg` a página completa; la página tiene la
etiqueta «Tapa» y la numeración del libro empieza en la portadilla. El EPUB la
declara como imagen de tapa.

**Portadilla.** Repite la jerarquía de la tapa —TUP26, título, materia, autor—
con la tipografía del interior.

**Marcadores del PDF.** 544, en tres niveles: partes, capítulos y secciones.

**Índice de un nivel.** Partes, capítulos y apéndices: veintinueve entradas que
entran en una página.

**Estructura de capítulo.** «Idea central» sin numerar, secciones numeradas
`N.M`, y al final «Errores frecuentes» y «Para recordar». Los veintidós capítulos
la tienen completa.

**Código.** Los 889 bloques llevan etiqueta. El capítulo 21 y el apéndice D
conservan el estilo de sus propios proyectos —comillas simples— porque son
aplicaciones verificadas que funcionan tal como están impresas.

**Enlaces.** Las referencias que el autor escribió en el texto se conservan y
funcionan en el PDF y en el EPUB.

---

## 7. Entregables

| Archivo | Contenido |
|---|---|
| `libro-programacion.pdf` | 363 páginas, con tapa y marcadores |
| `libro-programacion.epub` | EPUB 3 con tapa y metadatos completos |
| `libro-programacion.zip` | La carpeta del libro con los capítulos, el índice, el documento maestro y el registro editorial |

Los tres se generan desde `libro-completo.md`, que a su vez se arma con los
capítulos individuales.
