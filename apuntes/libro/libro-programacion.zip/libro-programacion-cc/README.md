# Programación Web

### Programación IV · TUP26

**Ing. Alejandro Di Battista**

---

## Estructura

Cinco partes, veintidós capítulos y seis apéndices.

| Parte | Capítulos | Contenido |
|---|---|---|
| I. Entender el lenguaje y sus valores | 1–8 | Lenguaje, motor y anfitrión; variables y expresiones; `boolean`, `number`, `bigint`, `string`, `undefined`, `null`, `symbol` y conversiones |
| II. Modelar colecciones y entidades | 9–11 | Arrays y matrices, objetos y referencias, `Map` y `Set` |
| III. Organizar el comportamiento | 12–16 | Estructuras de control, errores, funciones, programación funcional, recursividad y árboles |
| IV. Aplicar e integrar | 17–19 | Asincronía, expresiones regulares y archivos con Node.js |
| V. Construir para la Web | 20–22 | HTML, CSS y JavaScript en el navegador; Arrow.js; APIs REST |
| Apéndices | A–F | Tokenizador BPE, evaluador de expresiones, computación digital, agenda con Ink y React, referencia de regex, glosario |

El índice completo está en [`00-indice.md`](00-indice.md).

---

## Organización de carpetas

```text
libro-programacion-cc/
├── README.md                      este archivo
├── 00-indice.md                   índice
├── 00-informe-editorial.md        registro del proceso de edición
├── mapa-de-fuentes.md             trazabilidad del material original
├── libro-completo.md              documento maestro: la obra entera
├── 99-fuentes.md                  documentos citados
│
├── parte-1-entender-el-lenguaje-y-sus-valores/
│   ├── 01-del-problema-al-programa.md
│   ├── 02-variables-alcance-y-expresiones.md
│   ├── 03-el-tipo-boolean.md
│   ├── 04-number-y-bigint.md
│   ├── 05-string-y-unicode.md
│   ├── 06-undefined-null-y-ausencia.md
│   ├── 07-conversion-y-coercion.md
│   └── 08-symbol-y-protocolos.md
│
├── parte-2-modelar-colecciones-y-entidades/
│   ├── 09-arrays-y-matrices.md
│   ├── 10-objetos-y-referencias.md
│   └── 11-map-set-y-colecciones.md
│
├── parte-3-organizar-el-comportamiento/
│   ├── 12-estructuras-de-control.md
│   ├── 13-errores-y-excepciones.md
│   ├── 14-funciones.md
│   ├── 15-programacion-funcional-y-pipelines.md
│   └── 16-recursividad-y-arboles.md
│
├── parte-4-aplicar-e-integrar/
│   ├── 17-programacion-asincronica.md
│   ├── 18-expresiones-regulares.md
│   └── 19-archivos-con-nodejs.md
│
├── parte-5-construir-para-la-web/
│   ├── 20-desarrollo-web.md
│   ├── 21-arrowjs.md
│   └── 22-consumir-api-rest.md
│
└── apendices/
    ├── apendice-a-tokenizador-bpe.md
    ├── apendice-b-evaluar-expresiones.md
    ├── apendice-c-computacion-digital.md
    ├── apendice-d-agenda-con-ink-y-react.md
    ├── apendice-e-referencia-regex.md
    └── apendice-f-glosario.md
```

---

## Formatos

| Formato | Archivo |
|---|---|
| Markdown por capítulos | esta carpeta |
| Markdown consolidado | `libro-completo.md` |
| Paquete comprimido | `libro-programacion.zip` |
| EPUB, con tapa | `libro-programacion.epub` |
| PDF, con tapa y marcadores | `libro-programacion.pdf` |

`libro-completo.md` contiene la obra entera en el orden definitivo y se genera a
partir de los capítulos individuales, de modo que coincide con ellos por
construcción. El EPUB y el PDF se producen desde ese archivo, así que los tres
formatos comparten el mismo contenido.

---

## Decisiones editoriales relevantes

**Título, autor y tapa son los del autor.** Salen de la tapa del libro y del
informe editorial que acompaña los apuntes.

**Las partes siguen el índice del autor.** Se conservaron sus cuatro nombres y
se agregó una quinta parte para los capítulos de desarrollo web.

**Cada capítulo abre con su idea central** y cierra con «Errores frecuentes» y
«Para recordar». No hay ejercicios ni cuestionarios.

**El texto va directo al contenido.** No hay prefacio, introducción ni
explicaciones sobre cómo está armado el libro o cómo conviene leerlo.

**Los temas que aparecen más de una vez se resolvieron con una remisión** a la
sección exacta donde están desarrollados.

**El código se verificó ejecutándolo.** Las aplicaciones de la parte V se
corrieron completas, en Chromium y en Node.js, con los servicios externos
simulados; el detalle está en el informe editorial.

El detalle está en [`00-informe-editorial.md`](00-informe-editorial.md), y la
trazabilidad de cada archivo original en [`mapa-de-fuentes.md`](mapa-de-fuentes.md).

---

## Convenciones del texto

- Español argentino, con registro adecuado a un libro universitario.
- Nombres de variables en español; nombres del lenguaje y de sus APIs en inglés.
- Todos los bloques de código llevan etiqueta: `js`, `jsx`, `ts`, `html`, `css`,
  `http`, `json`, `bash` o `text`.
- La etiqueta `text` marca diagramas, tablas y salidas de consola, no código
  ejecutable.
- Los resultados se muestran como comentario al costado del código.
- Las remisiones indican la sección exacta: «la sección 20.11», «el apéndice B».
