# Capítulo 17. Programación asincrónica con `async` y `await`

## Idea central

**JavaScript ejecuta una sola cosa por vez, así que una operación que tarda no puede esperarse bloqueando: la función que la pide se suspende, el resto del programa sigue, y esa función retoma cuando el dato llega.** `async` y `await` expresan esa suspensión con la misma forma que tendría un programa secuencial, y por eso el manejo de errores vuelve a ser `try`/`catch`.

Lo que cambia respecto de un programa sincrónico no es la sintaxis sino el momento: entre el `await` y su resultado pueden ocurrir otras cosas. Diseñar bien la asincronía consiste, casi siempre, en decidir qué operaciones deben esperarse en fila y cuáles pueden arrancar juntas.

## 17.1 El problema: un solo hilo

Hay operaciones que tardan: pedir datos a un servidor, leer un archivo, esperar un segundo. JavaScript tiene **un solo hilo** de ejecución, así que no puede quedarse parado esperando. Si lo hiciera, la página entera se congela: no responde a un clic, no anima nada, no repinta.

La solución es no esperar bloqueando. La función que pide el dato se **suspende**, el resto del programa sigue corriendo, y cuando el dato llega la función retoma exactamente donde estaba.

Conviene separar dos ideas que suelen mezclarse. El motor ejecuta una tarea por vez; el anfitrión, en cambio, puede tener varias operaciones en curso —una descarga, una lectura de disco, un temporizador— y avisar cuando cada una termina. La sección 1.4 describió ese reparto entre motor y anfitrión. La sección 20.11 muestra el orden exacto en que el navegador procesa el código actual, las promesas y los temporizadores.

## 17.2 Una promesa es un valor que todavía no llegó

Las funciones que tardan no devuelven el dato: devuelven una **promesa** de ese dato.

Una promesa tiene tres estados y solo cambia una vez:

| Estado | Significado |
|---|---|
| pendiente | la operación está en curso |
| cumplida | terminó bien y tiene un valor |
| rechazada | falló y tiene un motivo |

```js
const promesa = fetch("/api/usuarios");

console.log(promesa); // Promise { <pending> }
```

Imprimir la promesa no imprime el dato. La promesa es el comprobante, no el resultado.

## 17.3 Las dos palabras

**`await`** espera a que la promesa termine y devuelve el valor:

```js
const respuesta = await fetch("/api/usuarios");
```

**`async`** marca la función que contiene `await`. Sin ella, `await` es un error de sintaxis:

```js
async function cargar() {
  const respuesta = await fetch("/api/usuarios");
  const usuarios = await respuesta.json();
  return usuarios;
}
```

Dos consecuencias, y son todo lo que hay que recordar:

- Una función `async` **siempre devuelve una promesa**. Por eso, para usar su resultado desde afuera, también hay que ponerle `await`.
- `await` **no bloquea el programa**: suspende solamente a *esa* función.

```js
const usuarios = await cargar(); // el await de afuera
```

Un `return valor` dentro de una función `async` produce una promesa cumplida con ese valor; un `throw`, una promesa rechazada.

> **Regla:** si una función tiene un `await` adentro, va marcada `async`. Si una función es `async`, al llamarla le va un `await`. Se contagia hacia arriba.

## 17.4 La forma que se usa siempre

El grueso del código asincrónico real tiene esta forma:

```js
async function mostrarUsuario(id) {
  const respuesta = await fetch(`/api/usuarios/${id}`);
  const usuario = await respuesta.json();
  document.querySelector("#nombre").textContent = usuario.nombre;
}
```

Dos detalles de `fetch` que conviene saber de memoria:

1. Hacen falta **dos `await`**: el primero espera la respuesta, el segundo espera y convierte el cuerpo, porque `json()` también devuelve una promesa.
2. **Un 404 no falla.** `fetch` solo rechaza si se cayó la red o se canceló el pedido. Hay que revisar `ok` a mano:

```js
if (!respuesta.ok) throw new Error(`Error ${respuesta.status}`);
```

La sección 13.14 desarrolla esta sutileza y muestra cómo traducir un estado HTTP a un error del dominio; la 22.8 explica por qué `fetch` se comporta así.

## 17.5 Errores: `try`/`catch` de siempre

Si la promesa se rechaza, `await` lanza una excepción. Se atrapa como cualquier otra:

```js
async function mostrarUsuario(id) {
  const cartel = document.querySelector("#estado");
  cartel.textContent = "Cargando...";

  try {
    const respuesta = await fetch(`/api/usuarios/${id}`);
    if (!respuesta.ok) throw new Error(`Error ${respuesta.status}`);

    const usuario = await respuesta.json();
    cartel.textContent = usuario.nombre;
  } catch (error) {
    cartel.textContent = `No se pudo cargar: ${error.message}`;
  } finally {
    document.querySelector("#boton").disabled = false; // siempre se ejecuta
  }
}
```

Un solo `try` cubre todos los `await` que haya adentro. Eso es cómodo y también es la trampa que describe la sección 13.10: si el bloque abarca demasiadas operaciones, el `catch` ya no sabe cuál falló.

La equivalencia con el estilo de promesas encadenadas es directa:

```js
cargarDatos()
  .then(usar)
  .catch(manejar)
  .finally(limpiar);
```

Las dos formas hacen lo mismo. Conviene elegir una por unidad de código: mezclarlas es la manera más común de perder un rechazo.

## 17.6 En paralelo: `Promise.all`

Este es el error más frecuente de todos.

```js
// MAL: tres segundos
const usuarios = await obtenerUsuarios(); // 1 s
const productos = await obtenerProductos(); // 1 s
const ventas = await obtenerVentas(); // 1 s
```

Los tres pedidos son independientes; no hay razón para hacerlos en fila:

```js
// BIEN: un segundo
const [usuarios, productos, ventas] = await Promise.all([
  obtenerUsuarios(),
  obtenerProductos(),
  obtenerVentas()
]);
```

Lo que cambia es *cuándo arranca cada uno*. Llamar a la función arranca el trabajo; `await` solamente espera el resultado. Dentro del arreglo, las tres arrancan juntas.

> **Regla:** si un `await` no usa el resultado del `await` anterior, están mal puestos.

## 17.7 Cuando `all` no alcanza

`Promise.all` rechaza en cuanto una de las promesas rechaza, y las demás siguen corriendo sin que nadie las mire. Hay tres combinadores más:

| Combinador | Termina cuando | Resultado |
|---|---|---|
| `all` | todas se cumplen, o una rechaza | array de valores, o el primer rechazo |
| `allSettled` | todas terminan, pase lo que pase | array de estados |
| `race` | termina la primera, se cumpla o rechace | ese valor o ese rechazo |
| `any` | se cumple la primera | ese valor, o `AggregateError` si fallan todas |

```js
const resultados = await Promise.allSettled([guardarA(), guardarB()]);
// cada uno: { status: "fulfilled", value } | { status: "rejected", reason }
```

`allSettled` es el adecuado cuando cada operación vale por sí misma y querés un informe completo. La sección 13.15 muestra cómo recorrer esos estados.

## 17.8 `await` dentro de un bucle

**Uno por vez**, cuando importa el orden o cada paso depende del anterior:

```js
for (const id of ids) {
  const usuario = await obtenerUsuario(id);
  console.log(usuario.nombre);
}
```

**Todos juntos**, cuando son independientes, que es lo habitual:

```js
const usuarios = await Promise.all(ids.map(id => obtenerUsuario(id)));
```

**`forEach` no funciona.** Ignora la promesa que devuelve el callback, así que no espera nada:

```js
ids.forEach(async id => {
  const usuario = await obtenerUsuario(id);
  console.log(usuario.nombre); // se imprime más tarde, sin orden garantizado
});

console.log("listo"); // se imprime primero, sin ningún dato
```

Con `async`: `for...of` o `map` más `Promise.all`. Nunca `forEach`.

Lanzar miles de pedidos a la vez tampoco es gratis. Cuando la cantidad de operaciones depende de los datos, conviene limitar la concurrencia; la sección 19.38 discute ese límite para archivos.

## 17.9 Secuencias que llegan por partes

Una promesa representa **un** valor futuro. Cuando lo que llega es una secuencia —páginas de un listado, líneas de un archivo, eventos— el protocolo adecuado es el iterable asincrónico, que se consume con `for await...of`:

```js
for await (const linea of lineas) {
  procesar(linea);
}
```

La sección 8.9 explica el protocolo y la sección 19.26 lo aplica a leer un archivo grande sin cargarlo entero en memoria.

## 17.10 `await` en el nivel superior de un módulo

Dentro de un módulo ECMAScript, `await` puede usarse fuera de toda función:

```js
import { readFile } from "node:fs/promises";

const configuracion = JSON.parse(await readFile("config.json", "utf8"));
```

El módulo queda suspendido hasta que la promesa termina, y los módulos que lo importan esperan con él. Es cómodo para cargar configuración al arrancar y desaconsejable para trabajo largo, porque demora a todo el que dependa de ese módulo.

## 17.11 Errores frecuentes

| Error | Síntoma | Solución |
|---|---|---|
| Olvidar `await` | sale `Promise { <pending> }` en vez del valor | agregar `await` |
| Olvidar el segundo `await` en `fetch` | el cuerpo nunca llega | `await respuesta.json()` |
| `await` en serie sobre cosas independientes | tarda N veces más | `Promise.all` |
| `forEach` con `async` | el código sigue de largo sin esperar | `for...of`, o `map` más `all` |
| No revisar `respuesta.ok` | un 404 se procesa como dato válido | `if (!respuesta.ok) throw ...` |
| `await` fuera de una función `async` | error de sintaxis, salvo en el nivel superior de un módulo | marcar la función con `async` |
| Llamar una `async` sin `await` ni `.catch` | el error se pierde en silencio | esperar la llamada o devolver la promesa |
| Mezclar `await` con `.then` en la misma función | rechazos sin manejar | elegir un estilo |

## 17.12 Para recordar

- Una promesa es un valor que todavía no llegó; tiene tres estados y solo cambia una vez.
- `async` convierte el resultado de una función en una promesa; `await` suspende esa función, no el programa.
- El manejo de errores vuelve a ser `try`/`catch`/`finally`, con las mismas reglas del capítulo 13.
- Llamar arranca el trabajo y `await` solo espera: de esa distinción salen `Promise.all` y la diferencia entre tres segundos y uno.
- `all`, `allSettled`, `race` y `any` responden preguntas distintas sobre un conjunto de operaciones.
- Para una secuencia de valores en el tiempo, el protocolo es `for await...of`, no una promesa.

```js
async function tarea() {
  try {
    const a = await pedirA(); // en fila: b necesita a
    const b = await pedirB(a);
    const [c, d] = await Promise.all([pedirC(), pedirD()]); // juntos
    return { a, b, c, d };
  } catch (error) {
    console.error(error);
  } finally {
    limpiar();
  }
}

await tarea();
```
