# Apéndice F. Glosario

Términos técnicos que usa el libro, con el capítulo o apéndice donde se desarrolla cada uno.

---

**Acarreo.** En una suma, el dígito que se traslada a la columna siguiente cuando el resultado excede la base. En el medio sumador es una de las dos salidas. *Apéndice C.*

**Accesibilidad.** Posibilidad de percibir, comprender y operar una interfaz con distintas capacidades y herramientas, como un lector de pantalla o la navegación por teclado. *Capítulo 20.*

**Alcance** (*scope*). Región del código desde la cual una vinculación resulta accesible. JavaScript tiene alcance global, de función y de bloque. *Capítulo 2.*

**Alcance léxico.** Regla por la cual el ámbito de una función queda determinado por el lugar donde fue escrita, no por el lugar desde donde se la invoca. Es la base de las clausuras. *Capítulos 2 y 14.*

**Analizador sintáctico** (*parser*). Programa que reconoce la estructura de un texto según una gramática y la convierte en una representación manipulable. Una expresión regular no alcanza cuando esa estructura admite anidamiento sin límite. *Capítulo 18 y apéndice B.*

**Ancla.** En una expresión regular, construcción que exige una posición sin consumir caracteres: `^`, `$`, `\b`. *Capítulo 18 y apéndice E.*

**Anfitrión** (*host*). Plataforma que ejecuta el motor y le aporta capacidades externas: el navegador con el DOM y los eventos, Node.js con archivos, procesos y red. *Capítulo 1.*

**API** (*Application Programming Interface*). Interfaz mediante la que un programa usa capacidades de otro componente. El DOM es una API del navegador; una API web ofrece sus servicios por HTTP. *Capítulos 20 y 22.*

**Argumento.** Valor concreto que se pasa a una función al invocarla. Se distingue del parámetro, que es el nombre declarado. *Capítulo 14.*

**Array.** Colección ordenada cuyos elementos se asocian con índices enteros que comienzan en cero. *Capítulo 9.*

**Array disperso.** Array con posiciones inexistentes, distintas de posiciones con `undefined`. Algunos métodos las saltan y otros las materializan. *Capítulos 6 y 9.*

**Asociatividad.** Regla que decide cómo se agrupan operadores de la misma precedencia. La mayoría asocia de izquierda a derecha; la exponenciación y la asignación, de derecha a izquierda. *Capítulo 2 y apéndice B.*

**Atributo** (HTML). Información que acompaña a la etiqueta de apertura de un elemento, como `class`, `id` o `href`. Los atributos booleanos se activan por su sola presencia. *Capítulo 20.*

**Autómata finito.** Máquina abstracta con una cantidad fija de estados que lee símbolos uno por uno. Las expresiones regulares describen, en su forma teórica, exactamente los lenguajes que un autómata finito puede reconocer. *Capítulo 18.*

**Bandera** (*flag*). En expresiones regulares, opción que modifica el modo de trabajo del patrón: `g`, `i`, `m`, `s`, `u`, `y`, `d`. *Capítulo 18 y apéndice E.*

**BigInt.** Tipo primitivo para enteros de precisión arbitraria. Su literal termina en `n` y no puede mezclarse directamente con `number` en operaciones aritméticas. *Capítulo 4.*

**Bit.** Unidad capaz de representar una de dos alternativas. Con `n` bits existen `2ⁿ` patrones posibles. *Apéndice C.*

**BOM** (*Byte Order Mark*). Marca opcional al comienzo de un archivo de texto. UTF-8 no la necesita, pero algunos programas la escriben y aparece como `U+FEFF`. *Capítulo 19.*

**BPE** (*Byte Pair Encoding*). Algoritmo que construye un vocabulario partiendo de bytes y fusionando, en orden, los pares más frecuentes. *Apéndice A.*

**Buffer.** Vista de bytes de Node.js. `readFile` sin codificación devuelve un `Buffer`; con codificación devuelve un string. *Capítulo 19.*

**Byte.** Grupo de ocho bits, capaz de 256 patrones. Es la unidad direccionable habitual de la memoria y la base del tokenizador del apéndice A. *Apéndice C y capítulo 19.*

**Cabecera** (*header*). Línea `Nombre: valor` de un mensaje HTTP que aporta metadatos sobre el pedido o la respuesta, como `Content-Type`. *Capítulo 22.*

**Cadena de alcances.** Secuencia de ámbitos que el motor consulta al resolver un nombre, desde el más interno hacia el global. *Capítulo 2.*

**Callback.** Función que se pasa como argumento para que otra la invoque. Puede ejecutarse enseguida, varias veces o en el futuro; el contrato debe aclararlo. *Capítulos 14 y 20.*

**Camino feliz.** Recorrido de un programa que supone que todo salió bien. Un ejemplo didáctico puede seguirlo deliberadamente, siempre que la decisión esté escrita. *Apéndice B.*

**Cascada.** Proceso por el que CSS decide qué declaración se aplica cuando varias compiten por la misma propiedad, según su origen, importancia, especificidad y orden. *Capítulo 20.*

**Clausura** (*closure*). Función que conserva acceso a las vinculaciones del ámbito donde fue creada, incluso después de que ese ámbito terminó. *Capítulos 2 y 14.*

**Clave de lista** (*key*). En una lista de componentes, identificador estable que permite saber qué elemento corresponde a qué dato cuando la lista se filtra o se reordena. *Capítulo 21 y apéndice D.*

**Cliente.** Programa que realiza una solicitud: un navegador, `curl` o una llamada a `fetch`. *Capítulos 20 y 22.*

**Codificación de caracteres.** Convenio que asigna secuencias de bytes a caracteres. UTF-8 es la codificación habitual de los archivos de texto. *Capítulos 5 y 19.*

**Código de estado.** Número de tres cifras con que una respuesta HTTP resume qué pasó con el pedido. El primer dígito indica la familia: `2xx` éxito, `4xx` error del cliente, `5xx` error del servidor. *Capítulo 22.*

**Coerción.** Conversión automática de tipo que aplica una operación porque necesita otro tipo del que recibió. *Capítulo 7.*

**Collation.** Orden de textos según reglas de un idioma, distinto del orden por unidades de código. `Intl.Collator` lo implementa. *Capítulo 5.*

**Combinador de promesas.** Función que coordina varias promesas: `Promise.all`, `allSettled`, `race` y `any`. Cada una responde una pregunta diferente. *Capítulo 17.*

**Compilador.** Programa que traduce código a otra representación antes de ejecutarlo. Un motor de JavaScript compila durante la ejecución las rutas que se usan con frecuencia. *Capítulo 1.*

**Completitud funcional.** Propiedad de un conjunto de operaciones lógicas que permite construir todas las demás. NAND por sí sola es funcionalmente completa; NOR también. *Apéndice C.*

**Componente.** Pieza reutilizable de interfaz que recibe datos y describe qué mostrar. *Capítulo 21 y apéndice D.*

**Contrapresión** (*backpressure*). Mecanismo que impide que un productor de datos avance mucho más rápido de lo que el consumidor puede procesar. *Capítulo 19.*

**Copia profunda.** Duplicado que recorre todos los niveles de una estructura. `structuredClone` la realiza para muchos tipos integrados. *Capítulo 10.*

**Copia superficial.** Duplicado de un solo nivel: la estructura exterior es nueva y los valores internos siguen siendo las mismas referencias. Es lo que hacen el spread, `Object.assign` y `slice`. *Capítulos 9 y 10.*

**CORS** (*Cross-Origin Resource Sharing*). Mecanismo por el que un servidor indica qué accesos admite desde páginas de otros orígenes. Se configura en el servidor, no en el cliente. *Capítulo 20.*

**Cortocircuito.** Comportamiento de `&&` y `||` que deja de evaluar en cuanto el resultado queda determinado, y devuelve un operando en lugar de un booleano. *Capítulo 3.*

**CRUD.** Las cuatro operaciones básicas sobre datos: crear, leer, actualizar y borrar. En REST se traducen a `POST`, `GET`, `PUT` o `PATCH` y `DELETE`. *Capítulo 22 y apéndice D.*

**Cuantificador.** En una expresión regular, construcción que indica cuántas veces puede repetirse el átomo anterior: `?`, `*`, `+`, `{n,m}`. *Capítulo 18 y apéndice E.*

**Desenrollado de la pila.** Proceso por el cual una excepción abandona las llamadas pendientes hasta encontrar un `catch`. *Capítulo 13.*

**Desestructuración.** Sintaxis que extrae valores de un array o propiedades de un objeto y los vincula con nombres locales. *Capítulos 9, 10 y 14.*

**Directorio de trabajo.** Carpeta desde la que se interpretan las rutas relativas de un proceso, disponible en `process.cwd()`. No coincide necesariamente con la carpeta del módulo. *Capítulo 19.*

**DOM** (*Document Object Model*). Representación del documento como árbol de nodos, con APIs para consultarlo y modificarlo. JavaScript cambia el DOM, no el archivo HTML. *Capítulo 20.*

**ECMAScript.** Estándar que define el núcleo del lenguaje. JavaScript es su implementación más conocida; las APIs del navegador y de Node.js pertenecen a otras especificaciones. *Capítulo 1.*

**Efecto secundario.** Cambio observable fuera de una función: escribir un archivo, mutar un argumento, imprimir, consultar el reloj. *Capítulo 15.*

**Elevación** (*hoisting*). Procesamiento de las declaraciones antes de ejecutar el bloque. Las declaraciones de función quedan utilizables; `let` y `const` quedan en la zona muerta temporal. *Capítulo 2.*

**Encadenamiento opcional** (`?.`). Operador que interrumpe una cadena de acceso y produce `undefined` cuando el valor anterior es `null` o `undefined`. *Capítulo 6.*

**Endpoint.** Dirección de una operación o de un recurso de una API. *Capítulos 20 y 22.*

**Especificidad.** Peso de un selector CSS, leído en tres columnas —identificadores; clases, atributos y pseudoclases; elementos— que se comparan de izquierda a derecha, sin sumarse. *Capítulo 20.*

**Estado de la aplicación.** Datos que describen la situación actual de una interfaz. En un enfoque declarativo, la pantalla se calcula a partir de él. *Capítulos 20 y 21, apéndice D.*

**Estado etiquetado.** Modelo que representa una situación con un campo explícito —«pendiente», «lista», «error»— en lugar de deducirla de un `null` ambiguo. *Capítulo 6.*

**Evento.** Notificación de algo ocurrido en el entorno —un clic, un envío, una tecla— a la que el programa responde con una función registrada. *Capítulo 20.*

**Excepción.** Señal de que una operación no pudo cumplir su contrato. Se propaga por la pila de llamadas hasta encontrar quien la maneje. *Capítulo 13.*

**Expresión.** Porción de código que produce un valor. Se distingue de una sentencia, que ejecuta una acción estructural. *Capítulo 2.*

**Expresión regular.** Descripción de un conjunto de secuencias de texto, construida con átomos, cantidades, alternativas y posiciones. *Capítulo 18 y apéndice E.*

**Fall-through.** En un `switch`, continuación de la ejecución en el caso siguiente por ausencia de `break`, `return` o `throw`. Puede ser intencional o un olvido. *Capítulo 12.*

**Falsy.** Valor cuya conversión booleana produce `false`. Son ocho: `false`, `0`, `-0`, `0n`, `""`, `null`, `undefined` y `NaN`. *Capítulo 3.*

**FileHandle.** Manejador devuelto por `open` que permite lecturas parciales, posiciones explícitas y varias operaciones sobre la misma apertura. Siempre debe cerrarse. *Capítulo 19.*

**Flexbox.** Modelo de distribución de CSS que organiza los hijos de un contenedor a lo largo de un eje principal. *Capítulo 20.*

**Forma normal disyuntiva.** Expresión booleana escrita como OR de términos AND. Permite construir una expresión para cualquier tabla de verdad finita. *Apéndice C.*

**Frontend** y **backend.** El frontend es la parte de una aplicación con la que interactúa la persona, y corre en su dispositivo; el backend procesa operaciones en servidores, cerca de los datos y de las reglas. *Capítulos 1 y 20.*

**Función de orden superior.** Función que recibe funciones como argumento o devuelve una función. *Capítulos 14 y 15.*

**Función pura.** Función que devuelve el mismo resultado para las mismas entradas y no cambia estado observable fuera de ella. *Capítulo 15.*

**Generador.** Función declarada con `function*` que produce valores bajo demanda mediante `yield`. Implementa el protocolo iterable sin escribirlo a mano. *Capítulo 14.*

**Geocodificación.** Conversión de una referencia textual, como el nombre de una ciudad, en ubicaciones con coordenadas. *Capítulos 20 y 22.*

**Grafema** (*grapheme cluster*). Unidad que una persona percibe como un solo carácter, aunque esté formada por varios puntos de código. `Intl.Segmenter` los recorre. *Capítulo 5.*

**Grid.** Modelo de distribución de CSS que organiza los hijos de un contenedor en filas y columnas. *Capítulo 20.*

**Guarda.** Condición al comienzo de una función que descarta un caso imposible y devuelve o lanza de inmediato, dejando visible el camino principal. *Capítulo 12.*

**Hook.** En React, función que da acceso a capacidades del renderizador, como `useState` o `useInput`. Se llama siempre en el nivel superior del componente. *Apéndice D.*

**HTTP** (*HyperText Transfer Protocol*). Protocolo de pedido y respuesta entre un cliente y un servidor. No guarda memoria entre un pedido y el siguiente. *Capítulo 22.*

**Idempotente.** Dicho de un método HTTP, que repetirlo deja el servidor igual que ejecutarlo una sola vez. `GET`, `PUT` y `DELETE` lo son; `POST`, no. *Capítulo 22.*

**Identidad.** Propiedad de un objeto de ser él mismo y no otro con el mismo contenido. `===` compara identidad, no igualdad de contenido. *Capítulo 10.*

**Identificador.** Nombre válido para una vinculación. Puede contener letras Unicode, dígitos, `_` y `$`, y no puede comenzar con un dígito. *Capítulo 2.*

**Inmutabilidad.** Práctica de producir una versión nueva en lugar de modificar un valor compartido. No exige clonar todo: se copia el camino que cambia y se comparte el resto. *Capítulos 15 y 16.*

**Interpolación.** Inserción del valor de una expresión dentro de una plantilla literal mediante `${...}`. *Capítulo 5.*

**Intérprete.** Programa que ejecuta código sin producir antes un binario separado. Los motores modernos combinan interpretación y compilación durante la misma ejecución. *Capítulo 1.*

**Invariante.** Condición que una estructura debe cumplir siempre. En un árbol binario de búsqueda, la relación de orden entre cada nodo y sus dos subárboles. *Capítulo 16.*

**Iterable.** Objeto que implementa `Symbol.iterator` y por eso puede recorrerse con `for...of`, expandirse con spread y desestructurarse. *Capítulos 8 y 12.*

**JIT** (*Just-In-Time*). Compilación durante la ejecución, con información recogida sobre los valores reales. Si las suposiciones dejan de cumplirse, el motor descarta la optimización. *Capítulo 1.*

**JSON** (*JavaScript Object Notation*). Formato de texto para intercambiar datos estructurados: objetos, arrays, cadenas, números, booleanos y `null`. No admite comentarios, fechas ni `undefined`. *Capítulos 10, 19 y 22.*

**JSX.** Sintaxis que describe elementos de React dentro de JavaScript. Una herramienta la transforma en llamadas que crean esos elementos. *Apéndice D.*

**Lenguaje regular.** Conjunto de cadenas que un autómata finito puede reconocer. Es exactamente lo que describe una expresión regular en su forma matemática. *Capítulo 18.*

**LIFO** (*last in, first out*). Disciplina de acceso de una pila: el último elemento que entra es el primero que sale. *Capítulo 9 y apéndice B.*

**Lookahead** y **lookbehind.** Construcciones de una expresión regular que exigen la presencia o ausencia de un patrón antes o después de la coincidencia, sin incluirlo en ella. *Capítulo 18.*

**Map.** Colección de pares clave–valor que acepta claves de cualquier tipo y conserva el orden de inserción. *Capítulo 11.*

**Máscara de bits.** Técnica que usa cada bit de un entero como una opción independiente, activada con `|`, consultada con `&`, apagada con `& ~` y alternada con `^`. *Capítulo 4 y apéndice C.*

**Media query.** Condición de CSS que aplica un grupo de reglas solo cuando se cumple, por ejemplo un ancho mínimo del viewport. *Capítulo 20.*

**Medio sumador.** Circuito que suma dos bits y produce suma y acarreo. La suma es XOR y el acarreo es AND. *Apéndice C.*

**Metacarácter.** Carácter con significado especial en una expresión regular: `. ^ $ * + ? ( ) [ ] { } | \`. *Capítulo 18.*

**Método HTTP.** Verbo de un pedido que indica la acción sobre el recurso: `GET`, `POST`, `PUT`, `PATCH` o `DELETE`. *Capítulo 22.*

**Modo estricto.** Semántica que convierte en errores varios comportamientos históricos permisivos. Los módulos ECMAScript lo aplican automáticamente. *Capítulo 1.*

**Motor.** Programa que lee y ejecuta código JavaScript, como V8, SpiderMonkey o JavaScriptCore. Compartir motor no implica compartir APIs. *Capítulo 1.*

**Mutación.** Modificación de un valor existente, en oposición a producir uno nuevo. `sort` y `splice` mutan; `toSorted` y `slice` no. *Capítulos 9 y 10.*

**NaN** (*Not a Number*). Valor del tipo `number` que representa un resultado numérico indeterminado. No es igual a sí mismo; se detecta con `Number.isNaN`. *Capítulo 4.*

**Normalización Unicode.** Transformación de un texto a una forma acordada —`NFC`, `NFD`, `NFKC`, `NFKD`— para que secuencias equivalentes se comparen como iguales. *Capítulo 5.*

**Objeto.** Colección de propiedades con nombre que representa una entidad. Las variables guardan una referencia, no el objeto. *Capítulo 10.*

**Parámetro.** Nombre declarado en la definición de una función. *Capítulo 14.*

**Parámetro rest.** Último parámetro escrito con `...`, que reúne en un array los argumentos restantes. *Capítulo 14.*

**Path traversal.** Vulnerabilidad que permite salir de un directorio autorizado mediante segmentos `..` en una ruta controlada por el usuario. *Capítulo 19.*

**Pila** (*stack*). Colección en la que se agrega y se quita por un solo extremo, llamado tope. Es la memoria mínima necesaria para tratar estructuras anidadas. *Apéndice B.*

**Pila de llamadas** (*call stack*). Registro de las llamadas a función pendientes de retornar. Determina el recorrido de una excepción y limita la profundidad de la recursión. *Capítulos 13 y 16.*

**Pipeline.** Encadenamiento de transformaciones donde cada etapa tiene una responsabilidad: seleccionar, transformar, acumular. *Capítulo 15.*

**Plantilla etiquetada.** Plantilla literal precedida por una función, que recibe por separado las partes estáticas y los valores interpolados. *Capítulos 5 y 21.*

**Plantilla literal.** Cadena delimitada por comillas invertidas, que admite interpolación y varias líneas. *Capítulo 5.*

**Polyfill.** Implementación en JavaScript de una funcionalidad ausente en un entorno. Una transformación de sintaxis no reemplaza a un polyfill. *Capítulo 1.*

**Precedencia.** Regla que decide cómo se agrupan operadores distintos cuando no hay paréntesis. *Capítulo 2 y apéndice B.*

**Primitivo.** Valor que no es un objeto. JavaScript tiene siete tipos primitivos: `boolean`, `number`, `bigint`, `string`, `undefined`, `null` y `symbol`. *Capítulos 3 a 8.*

**Promesa.** Objeto que representa un valor que todavía no llegó. Tiene tres estados —pendiente, cumplida, rechazada— y solo cambia una vez. *Capítulos 17, 20 y 22.*

**Props.** En React, información que un componente recibe de quien lo usa. Pueden ser datos o funciones. *Apéndice D.*

**Punto de código.** Número que Unicode asigna a un carácter. En UTF-16 puede necesitar una o dos unidades de código. *Capítulo 5.*

**Reactividad.** Propiedad de una interfaz que se actualiza sola cuando cambian los datos de los que depende. *Capítulo 21.*

**Recursividad.** Técnica en la que una función se llama a sí misma sobre una entrada más pequeña. Necesita un caso base, una reducción y una combinación. *Capítulo 16.*

**Referencia.** Valor que identifica a un objeto. Asignar una variable copia la referencia, no el objeto. *Capítulo 10.*

**Relanzamiento** (*rethrow*). Volver a lanzar el error capturado, en lugar de envolverlo en uno nuevo, cuando esta capa no puede manejarlo. *Capítulo 13.*

**Renderizador.** Biblioteca que transforma los elementos de React en una interfaz concreta: React DOM en el navegador, Ink en la terminal. *Apéndice D.*

**Renderizar.** Producir o actualizar una representación visible a partir de contenido o datos. *Capítulo 20 y apéndice D.*

**REST** (*Representational State Transfer*). Estilo de diseño de APIs web en el que cada recurso tiene una URL y los métodos HTTP son las acciones sobre él. *Capítulo 22.*

**Selector.** Expresión de CSS que identifica los elementos a los que se aplica una regla, como `.tarjeta` o `#estado`. `querySelector` usa la misma sintaxis desde JavaScript. *Capítulo 20.*

**Semántica.** Significado de los elementos de un documento y de sus relaciones, independiente de cómo se ven. *Capítulo 20.*

**Servidor.** Programa que recibe solicitudes y entrega respuestas. *Capítulos 20 y 22.*

**Set.** Colección de valores únicos que conserva el orden de la primera inserción y compara objetos por identidad. *Capítulo 11.*

**Sombreado** (*shadowing*). Declaración de un nombre en un ámbito interior que oculta otro del mismo nombre en un ámbito exterior. *Capítulo 2.*

**Stream.** Flujo de datos que llega por partes, sin cargar todo el contenido en memoria. Los fragmentos no coinciden con límites semánticos como una línea. *Capítulo 19.*

**Symbol.** Tipo primitivo cuyos valores son identidades únicas. Usado como clave de propiedad evita colisiones; los símbolos conocidos permiten participar en protocolos del lenguaje. *Capítulo 8.*

**Tabla de verdad.** Enumeración de todas las combinaciones de entrada de una función booleana y su salida. Para `n` entradas tiene `2ⁿ` filas. *Apéndice C.*

**Tipado dinámico.** Comprobación de tipos durante la ejecución, con valores reales. Cada valor tiene un tipo, aunque una variable no quede asociada a uno. *Capítulo 1.*

**Tipado estático.** Comprobación de tipos antes de ejecutar, realizada por una herramienta como TypeScript. Sus anotaciones desaparecen en tiempo de ejecución. *Capítulo 1.*

**Token.** En el apéndice A, identificador que representa un byte base o la concatenación de dos tokens anteriores. En un analizador, unidad léxica de la entrada. *Apéndices A y B.*

**Transpilación.** Transformación de código fuente a otro código fuente de nivel parecido, por ejemplo de sintaxis moderna a una compatible con entornos antiguos. *Capítulo 1.*

**Truthy.** Valor cuya conversión booleana produce `true`. Son todos los que no están en la lista de falsy, incluidos `[]`, `{}` y `"0"`. *Capítulo 3.*

**TUI** (*terminal user interface*). Interfaz de usuario dibujada con texto en una terminal, medida en columnas y filas. *Apéndice D.*

**TypeScript.** Lenguaje que agrega análisis estático de tipos sobre JavaScript. Se transforma a JavaScript para ejecutarse y no valida datos externos por sí solo. *Capítulo 1.*

**Unicode.** Estándar que asigna un punto de código a cada carácter. No define cómo se almacenan esos códigos: de eso se ocupan UTF-8 y UTF-16. *Capítulos 5 y 19.*

**URL.** Dirección de un recurso, formada por esquema, host, puerto, ruta, query y fragmento. *Capítulos 20 y 22.*

**UTF-16.** Representación interna de los strings de JavaScript. `length` y los índices cuentan unidades de código UTF-16, no caracteres visibles. *Capítulo 5.*

**UTF-8.** Codificación de ancho variable que representa cada punto de código con uno a cuatro bytes. Es la habitual en archivos y en la red. *Capítulos 5 y 19, apéndice A.*

**Variable.** Nombre vinculado con un valor durante una parte de la ejecución. `const` fija el vínculo, no el valor. *Capítulo 2.*

**Viewport.** Área de la ventana que el navegador usa como referencia para presentar el documento. *Capítulo 20.*

**Vinculación** (*binding*). Asociación entre un nombre y un valor dentro de un alcance. *Capítulo 2.*

**WeakMap** y **WeakSet.** Colecciones que asocian datos con objetos sin impedir que el recolector los libere. No son enumerables ni tienen `size`. *Capítulo 11.*

**Zona muerta temporal** (*Temporal Dead Zone*). Intervalo entre el comienzo de un bloque y la inicialización de un `let` o `const`, durante el cual leer el nombre lanza `ReferenceError`. *Capítulo 2.*
