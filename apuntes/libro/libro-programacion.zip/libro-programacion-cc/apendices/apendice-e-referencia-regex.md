# Apéndice E. Referencia rápida de expresiones regulares

## Idea central

**Una expresión regular se lee como la combinación de cuatro preguntas: qué carácter, cuántas veces, en qué posición y cómo se agrupa.** Esta referencia reúne la sintaxis en tablas de consulta; la explicación de cada construcción, con sus casos límite, está en el capítulo 18.

Todos los patrones de estas tablas suponen la bandera `u`, que activa la semántica Unicode y una sintaxis más estricta.

---

## E.1 Átomos: qué carácter

| Expresión | Significado |
|---|---|
| `abc` | la secuencia literal `abc` |
| `.` | cualquier carácter, salvo los terminadores de línea |
| `\d` | un dígito ASCII, equivale a `[0-9]` |
| `\D` | cualquier cosa que no sea un dígito ASCII |
| `\w` | carácter de palabra: `[A-Za-z0-9_]` |
| `\W` | lo contrario de `\w` |
| `\s` | espacio en blanco: espacio, tabulación, salto de línea |
| `\S` | lo contrario de `\s` |
| `[abc]` | uno de estos caracteres |
| `[a-z]` | un carácter del rango |
| `[^abc]` | cualquier carácter salvo estos |
| `\p{L}` | carácter Unicode con propiedad «letra» |
| `\p{N}` | carácter Unicode con propiedad «número» |
| `\p{Script=Greek}` | carácter del alfabeto griego |
| `\P{L}` | lo contrario de `\p{L}` |
| `\uXXXX` | un carácter por su código de cuatro dígitos hexadecimales |
| `\u{1F600}` | un punto de código Unicode completo |
| `\n`, `\t`, `\r` | salto de línea, tabulación, retorno de carro |

Los metacaracteres `. ^ $ * + ? ( ) [ ] { } | \` se escriben con barra invertida cuando se buscan literalmente. Dentro de una clase `[...]` las reglas cambian: `-`, `]`, `^` y `\` pueden necesitar atención según su posición.

---

## E.2 Cuantificadores: cuántas veces

Se aplican al átomo inmediatamente anterior.

| Expresión | Significado |
|---|---|
| `x?` | cero o una `x` |
| `x*` | cero o más `x` |
| `x+` | una o más `x` |
| `x{3}` | exactamente tres |
| `x{2,5}` | entre dos y cinco |
| `x{2,}` | dos o más |
| `x*?`, `x+?`, `x??`, `x{2,}?` | la variante perezosa: consume lo mínimo |

Por defecto los cuantificadores son codiciosos: consumen lo máximo posible y retroceden si hace falta. Cuando existe un delimitador conocido, una clase negada suele ser más precisa y más barata que una variante perezosa: `<[^>]*>` frente a `<.*?>`.

---

## E.3 Posiciones: dónde

Las anclas no consumen caracteres; solo exigen una posición.

| Expresión | Significado |
|---|---|
| `^` | comienzo del texto, o de cada línea con la bandera `m` |
| `$` | final del texto, o de cada línea con la bandera `m` |
| `\b` | frontera de palabra, definida a partir de `\w` |
| `\B` | posición que no es frontera de palabra |
| `(?=...)` | *lookahead* positivo: lo que sigue coincide |
| `(?!...)` | *lookahead* negativo: lo que sigue no coincide |
| `(?<=...)` | *lookbehind* positivo: lo anterior coincide |
| `(?<!...)` | *lookbehind* negativo: lo anterior no coincide |

Sin anclas, un patrón pregunta si existe una coincidencia en alguna parte. Con `^` y `$` pregunta si el texto completo tiene esa forma. Es la diferencia entre buscar y validar.

---

## E.4 Grupos y alternativas

| Expresión | Significado |
|---|---|
| `(...)` | grupo capturante: agrupa y guarda lo coincidente |
| `(?:...)` | grupo no capturante: agrupa sin ocupar una posición |
| `(?<nombre>...)` | grupo con nombre |
| `a\|b` | alternativa: `a` o `b` |
| `\1`, `\2` | referencia a la captura número 1, 2 |
| `\k<nombre>` | referencia a la captura con ese nombre |

La alternativa tiene la precedencia más baja: `rojo|verde$` significa `rojo` en cualquier posición o `verde` al final. Los paréntesis hacen visible el alcance.

---

## E.5 Banderas

| Bandera | Efecto |
|---|---|
| `g` | recorre todas las coincidencias y usa `lastIndex` |
| `i` | ignora diferencias de mayúsculas |
| `m` | `^` y `$` operan por línea |
| `s` | `.` también coincide con terminadores de línea |
| `u` | semántica Unicode y sintaxis estricta |
| `y` | coincidencia adherida a `lastIndex` |
| `d` | expone los índices de cada rango coincidente |

```js
const patron = /hola/giu;

patron.flags;  // "giu"
patron.global; // true
patron.source; // "hola"
```

---

## E.6 Métodos: qué devuelve cada uno

| Llamada | Devuelve | Necesita `g` |
|---|---|---|
| `patron.test(texto)` | booleano | no; con `g` conserva `lastIndex` |
| `patron.exec(texto)` | detalle de una coincidencia, o `null` | no; con `g` avanza en cada llamada |
| `texto.match(patron)` | detalle de la primera coincidencia | no |
| `texto.match(patron)` con `g` | array de textos completos, sin grupos | sí |
| `texto.matchAll(patron)` | iterador con el detalle de cada coincidencia | sí, es obligatoria |
| `texto.replace(patron, x)` | texto nuevo, solo la primera coincidencia | no |
| `texto.replaceAll(patron, x)` | texto nuevo, todas las coincidencias | sí, es obligatoria |
| `texto.search(patron)` | índice de la primera coincidencia, o `-1` | no |
| `texto.split(patron)` | array de fragmentos | no |

En un reemplazo, `$1` y `$<nombre>` insertan capturas, `$&` la coincidencia completa y `$$` un signo de peso literal. Una función de reemplazo recibe la coincidencia, las capturas, el índice y el texto completo.

---

## E.7 Recetas comprobadas

```js
// normalizar espacios
texto.trim().replace(/\s+/gu, " ");

// extraer números, con signo y decimales
[...texto.matchAll(/[+-]?\d+(?:[.,]\d+)?/gu)].map(m => m[0]);

// etiquetas Unicode
[...texto.matchAll(/#(?<etiqueta>[\p{L}\p{N}_]+)/gu)].map(m => m.groups.etiqueta);

// hora de 24 horas, texto completo
/^(?:[01]\d|2[0-3]):[0-5]\d$/u;

// código con la forma ABC-1234
/^[A-Z]{3}-\d{4}$/u;

// fecha: solo la forma; el calendario se valida aparte
/^(?<dia>\d{2})\/(?<mes>\d{2})\/(?<anio>\d{4})$/u;

// escapar texto del usuario antes de interpolarlo
texto.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
```

---

## E.8 Antes de escribir una regex

| Si el problema es… | La herramienta es… |
|---|---|
| buscar una secuencia fija | `includes`, `startsWith`, `endsWith`, `indexOf` |
| reemplazar un texto fijo | `replaceAll` con un string |
| separar por un carácter fijo | `split` con un string |
| interpretar JSON | `JSON.parse` |
| interpretar HTML o XML | un analizador estructural |
| interpretar CSV completo | una biblioteca de CSV |
| segmentar palabras de un idioma | `Intl.Segmenter` |
| comparar u ordenar texto humano | `Intl.Collator` |
| estructuras anidadas sin límite | un analizador sintáctico; el apéndice B construye uno |

---

## E.9 Para recordar

- La bandera `u` debería ser el punto de partida de todo patrón moderno; `\d` y `\w` siguen siendo ASCII, y para alfabetos generales van las propiedades Unicode.
- Sin anclas se busca; con `^` y `$` se valida.
- `g` no es un detalle: cambia lo que devuelve `match`, obliga en `matchAll` y `replaceAll`, y agrega estado a `test` y `exec`.
- Una captura que nadie usa conviene escribirla como grupo no capturante.
- Los cuantificadores anidados y ambiguos son la causa habitual del retroceso excesivo; ante entradas externas, limitá el tamaño y probá con casos adversos.
- Una expresión regular describe la forma de un texto. El significado —que una fecha exista, que un correo se entregue— lo valida el código que viene después.
