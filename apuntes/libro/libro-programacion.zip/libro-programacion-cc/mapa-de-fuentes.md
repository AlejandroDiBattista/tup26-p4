# Mapa de fuentes

Trazabilidad del material de origen: la carpeta `apuntes`, archivos `00` a `22`,
más los apéndices y la tapa. Cada archivo tiene una entrada que indica a qué
parte del libro fue a parar, qué se hizo con su contenido y en qué estado quedó.

## Estados utilizados

| Estado | Significado |
|---|---|
| incorporado | Su contenido pasó al libro con edición de estilo |
| ampliado | Se le agregó material que faltaba |
| reducido | Se recortó por solapamiento con otro capítulo |
| reescrito | Se rehizo la redacción conservando el contenido |
| dividido | Se repartió entre varios lugares del libro |
| usado como metadato | Aportó título, autor, estructura o tapa, no texto |
| sin usar | Estaba en la carpeta pero no forma parte de la edición |

---

## Tabla de trazabilidad

### Archivos 00: metadatos de la edición

| Archivo | Qué aportó | Estado |
|---|---|---|
| `00-indice.md` | Los nombres de las cuatro partes. Su párrafo de tesis, la descripción del método de escritura, las rutas de lectura y el método de estudio no se incorporaron: explican cómo leer el libro, no su contenido. Sus remisiones a `17-fundamentos-de-computacion-digital.md` y `apendices/100-tokens.md` apuntaban a archivos que ya no existen con esos nombres | usado como metadato |
| `00-informe-editorial.md` | Autor, nombre de la edición y confirmación de que la tapa acompaña al libro | usado como metadato |
| `portada.jpg` | Tapa del PDF y del EPUB; su diseño guía la portadilla | usado como metadato |

### Capítulos 01 a 19

Idénticos, byte por byte, a los de la edición anterior: se comprobó con su
huella MD5. Conservan todo el trabajo editorial ya hecho sobre ellos —apertura
completa, remisiones, reducción de solapamientos y la ampliación del capítulo
17—, más las remisiones nuevas hacia la parte V.

| Archivos | Destino | Estado |
|---|---|---|
| `01` a `08` | Parte I, capítulos 1 a 8 | incorporado; el 1 ampliado con errores frecuentes; el 5 y el 6 reducidos |
| `09` a `11` | Parte II, capítulos 9 a 11 | incorporado; el 9 reducido |
| `12` a `16` | Parte III, capítulos 12 a 16 | incorporado; el 12 reducido |
| `17` a `19` | Parte IV, capítulos 17 a 19 | incorporado; el 17 ampliado y reescrito; el 18 dividido con el apéndice E |

### Capítulos nuevos

| Archivo | Tema | Destino | Acción realizada | Estado |
|---|---|---|---|---|
| `20-desarrollo-web.md` | HTML, CSS, JavaScript en el navegador, DOM, eventos, HTTP, JSON, promesas, ciclo de eventos y una aplicación del clima completa | Capítulo 20 | Se agregó la idea central. El índice interno se quitó; el glosario pasó al apéndice F y las fuentes a la sección final. Los problemas frecuentes se integraron en «Errores frecuentes», que suma once confusiones que el propio capítulo desarma. Se corrigió «cascada e herencia» | incorporado, dividido, ampliado |
| `21-arrowjs.md` | Interfaces reactivas con Arrow.js: estado, plantillas, componentes, listas con clave, búsqueda, diálogo de alta y eliminación | Capítulo 21 | La frase inicial pasó a ser la idea central; se quitó la tabla de pasos, que describía la estructura del capítulo. Se agregaron errores frecuentes y «Para recordar» | incorporado, ampliado |
| `21-arrowjs.html` | Versión HTML del mismo capítulo, con los mismos títulos | — | Se usó la versión Markdown | sin usar |
| `22-consumir-api-rest.md` | HTTP, REST, códigos de estado, JSON, JSONPlaceholder, REST Client, cURL, `fetch` y una aplicación del clima para la terminal con Ink | Capítulo 22 | Se agregó la idea central y se quitó la lista de contenidos inicial. Los ejercicios finales pasaron a ser texto expositivo. El resumen se repartió entre «Errores frecuentes» y «Para recordar». Se corrigieron tres errores técnicos, detallados en el informe | incorporado, reescrito, ampliado |

### Apéndices y material final

| Archivo | Destino | Estado |
|---|---|---|
| `apendices/140-tokens.md` | Apéndice A | incorporado; idéntico a la edición anterior |
| `apendices/110-evaluar-expresion.md` | Apéndice B | incorporado y corregido; idéntico a la edición anterior |
| `apendices/100-fundamentos-de-computacion-digital.md` | Apéndice C | incorporado; idéntico a la edición anterior |
| `apendices/120-tutorial-ink-react.md` | Apéndice D | incorporado y reparado; idéntico a la edición anterior |
| `apendices/130-tutorial-crud-ink-react.md` | — | sin usar: está fuera del rango `00` a `22` y no formaba parte de la edición anterior |
| — | Apéndice E. Referencia de regex | contenido derivado del capítulo 18 |
| — | Apéndice F. Glosario | contenido derivado de toda la obra; suma los términos del glosario del capítulo 20 |
| — | Fuentes | reúne las fuentes del capítulo 20 y los documentos citados en los capítulos 21 y 22 y en el apéndice D |

---

## Cobertura inversa: de dónde viene cada capítulo

| Capítulo o apéndice | Fuente |
|---|---|
| 1 a 19 | `01` a `19` de la carpeta `apuntes` |
| 20. Desarrollo web | `20-desarrollo-web.md` |
| 21. Arrow.js | `21-arrowjs.md` |
| 22. Cómo consumir una API REST | `22-consumir-api-rest.md` |
| Apéndice A. Tokenizador BPE | `apendices/140-tokens.md` |
| Apéndice B. Evaluar expresiones con pilas | `apendices/110-evaluar-expresion.md` |
| Apéndice C. Computación digital | `apendices/100-fundamentos-de-computacion-digital.md` |
| Apéndice D. Agenda con Ink y React | `apendices/120-tutorial-ink-react.md` |
| Apéndice E. Referencia de regex | Derivado del capítulo 18 |
| Apéndice F. Glosario | Derivado de toda la obra |
| Fuentes | Capítulos 20 a 22 y apéndice D |
