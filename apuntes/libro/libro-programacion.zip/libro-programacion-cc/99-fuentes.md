# Fuentes

Documentos originales citados en el texto: estándares, historia de la Web y documentación de las bibliotecas y servicios que usan los proyectos.

## Capítulo 20. Desarrollo web

- Historia de la Web: [CERN, el nacimiento de la Web](https://home.cern/science/computing/the-birth-of-the-web/) y [los componentes de 1990](https://home.cern/world-wide-web-35/).
- Historia de CSS: [W3C](https://www.w3.org/Style/CSS20/history.html).
- HTML: [sintaxis y estructura en MDN](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax).
- CSS: [cascada](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Handling_conflicts), [modelo de caja](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model), [Flexbox](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Flexbox) y [Grid](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Grids).
- JavaScript: [estándar ECMAScript](https://ecma-international.org/publications-and-standards/standards/ecma-262/) y [modelo de ejecución](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Execution_model).
- APIs del navegador: [DOM](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model), [eventos](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events) y [Fetch](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch).
- Servicios del proyecto: [geocodificación de Open-Meteo](https://open-meteo.com/en/docs/geocoding-api), [datos meteorológicos y códigos](https://open-meteo.com/en/docs), [condiciones de uso](https://open-meteo.com/en/terms) y [licencia y atribución](https://open-meteo.com/en/licence).

## Capítulo 21. Arrow.js

- Arrow.js: [plantillas](https://arrow-js.com/#templates), [componentes](https://arrow-js.com/api/#component) y [la función `html`, con sus vinculaciones de propiedades y eventos](https://arrow-js.com/api/#html).
- MDN: [plantillas etiquetadas](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#tagged_templates) y [el elemento `dialog`](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/dialog).

## Capítulo 22. API REST

- [API de pronóstico de Open-Meteo](https://open-meteo.com/en/docs), la misma del capítulo 20.
- JSONPlaceholder, la API de práctica: `https://jsonplaceholder.typicode.com`.
- REST Client, extensión de Visual Studio Code de Huachao Mao.

## Apéndice D. Agenda con React e Ink

- React: [describir la interfaz](https://react.dev/learn/describing-the-ui), [el estado como memoria de un componente](https://react.dev/learn/state-a-components-memory), [actualizar arrays](https://react.dev/learn/updating-arrays-in-state) y [objetos en el estado](https://react.dev/learn/updating-objects-in-state), [diseñar el estado](https://react.dev/learn/thinking-in-react) y [conservar o reiniciar el estado](https://react.dev/learn/preserving-and-resetting-state).
- Ink: [documentación](https://github.com/vadimdemedes/ink), [TextInput](https://github.com/vadimdemedes/ink-text-input), [SelectInput](https://github.com/vadimdemedes/ink-select-input) y [sus props](https://github.com/vadimdemedes/ink-select-input#props), [Form](https://github.com/lukasbach/ink-form) y [su contrato](https://lukasbach.github.io/ink-form/interfaces/FormProps.html).
- Node.js: [el módulo `fs`](https://nodejs.org/api/fs.html).
