const { terminal: term } = require("terminal-kit");
const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "agenda.json");

let contactos = cargarContactos();
let siguienteId =
  contactos.length > 0
    ? Math.max(...contactos.map(c => c.id)) + 1
    : 1;

function cargarContactos() {
  if (!fs.existsSync(DB_FILE)) {
    return [
      {
        id: 1,
        nombre: "Ana Pérez",
        telefono: "3815551111",
        email: "ana@gmail.com"
      },
      {
        id: 2,
        nombre: "Carlos Gómez",
        telefono: "3814442222",
        email: "carlos@empresa.com"
      },
      {
        id: 3,
        nombre: "María López",
        telefono: "3814333333",
        email: "maria@hotmail.com"
      }
    ];
  }

  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch {
    return [];
  }
}

function guardarContactos() {
  fs.writeFileSync(
    DB_FILE,
    JSON.stringify(contactos, null, 2),
    "utf8"
  );
}

function normalizar(texto) {
  return String(texto ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
}

function buscarContactos(consulta) {
  const palabras = normalizar(consulta)
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (palabras.length === 0) {
    return contactos;
  }

  return contactos.filter(contacto => {
    const texto = normalizar(
      `${contacto.nombre} ${contacto.telefono} ${contacto.email}`
    );

    return palabras.every(palabra =>
      texto.includes(palabra)
    );
  });
}

async function pedirTexto(etiqueta, valor = "") {
  term(`${etiqueta}: `);

  const resultado = await term.inputField({
    default: valor,
    cancelable: true
  }).promise;

  term("\n");

  return resultado;
}

async function esperarTecla() {
  term.gray("\nPresione cualquier tecla...");

  term.grabInput();

  await new Promise(resolve => {
    const handler = () => {
      term.off("key", handler);
      resolve();
    };

    term.on("key", handler);
  });
}

async function crearContacto() {
  term.clear();
  term.bold.green("NUEVO CONTACTO\n\n");

  const nombre = await pedirTexto("Nombre");
  if (nombre === undefined) return;

  const telefono = await pedirTexto("Teléfono");
  if (telefono === undefined) return;

  const email = await pedirTexto("Email");
  if (email === undefined) return;

  contactos.push({
    id: siguienteId++,
    nombre,
    telefono,
    email
  });

  guardarContactos();

  term.green("\nContacto creado correctamente.\n");
  await esperarTecla();
}

async function editarContacto(contacto) {
  term.clear();
  term.bold.yellow("EDITAR CONTACTO\n\n");

  const nombre = await pedirTexto(
    "Nombre",
    contacto.nombre
  );
  if (nombre === undefined) return;

  const telefono = await pedirTexto(
    "Teléfono",
    contacto.telefono
  );
  if (telefono === undefined) return;

  const email = await pedirTexto(
    "Email",
    contacto.email
  );
  if (email === undefined) return;

  contacto.nombre = nombre;
  contacto.telefono = telefono;
  contacto.email = email;

  guardarContactos();

  term.green("\nContacto actualizado.\n");
  await esperarTecla();
}

async function eliminarContacto(contacto) {
  term.clear();
  term.red.bold("ELIMINAR CONTACTO\n\n");

  term(`¿Eliminar a ${contacto.nombre}? `);

  const respuesta = await term.yesOrNo({
    yes: ["y", "Y", "s", "S"],
    no: ["n", "N"]
  }).promise;

  term("\n");

  if (!respuesta) {
    term.yellow("Operación cancelada.\n");
    await esperarTecla();
    return false;
  }

  contactos = contactos.filter(
    c => c.id !== contacto.id
  );

  guardarContactos();

  term.green("Contacto eliminado.\n");
  await esperarTecla();

  return true;
}

async function menuContacto(contacto) {
  while (true) {
    term.clear();

    term.bold.cyan(`${contacto.nombre}\n\n`);

    term(`ID:       ${contacto.id}\n`);
    term(`Teléfono: ${contacto.telefono}\n`);
    term(`Email:    ${contacto.email}\n\n`);

    const respuesta = await term.singleColumnMenu(
      [
        "Editar",
        "Eliminar",
        "Volver"
      ],
      {
        cancelable: true
      }
    ).promise;

    if (!respuesta) return;

    switch (respuesta.selectedIndex) {
      case 0:
        await editarContacto(contacto);
        break;

      case 1:
        if (await eliminarContacto(contacto)) {
          return;
        }
        break;

      case 2:
        return;
    }
  }
}

async function principal() {
  while (true) {
    term.clear();

    term.bold.cyan("AGENDA\n\n");
    term("Búsqueda flexible por nombre, teléfono o email.\n");
    term.gray("Ejemplos: ana gmail | perez 555 | 38144\n\n");

    term("Buscar: ");

    const consulta = await term.inputField({
      cancelable: true
    }).promise;

    if (consulta === undefined) {
      salir();
      return;
    }

    const resultados = buscarContactos(consulta);

    term("\n\n");

    const opciones = resultados.map(c =>
      `${c.nombre.padEnd(22)} ${c.telefono.padEnd(14)} ${c.email}`
    );

    if (resultados.length === 0) {
      opciones.push("(Sin resultados)");
    }

    opciones.push("");
    opciones.push("[ Nuevo contacto ]");
    opciones.push("[ Nueva búsqueda ]");
    opciones.push("[ Salir ]");

    const respuesta = await term.singleColumnMenu(
      opciones,
      {
        cancelable: true,
        selectedStyle: term.black.bgCyan
      }
    ).promise;

    if (!respuesta) {
      salir();
      return;
    }

    const indice = respuesta.selectedIndex;
    const base = resultados.length === 0 ? 1 : resultados.length;

    if (resultados.length > 0 && indice < resultados.length) {
      await menuContacto(resultados[indice]);
      continue;
    }

    const nuevoIndex = base + 1;
    const buscarIndex = base + 2;
    const salirIndex = base + 3;

    if (indice === nuevoIndex) {
      await crearContacto();
    } else if (indice === buscarIndex) {
      continue;
    } else if (indice === salirIndex) {
      salir();
      return;
    }
  }
}

function salir() {
  term.grabInput(false);
  term.clear();
  term.green("Hasta luego.\n");
  process.exit();
}

process.on("SIGINT", salir);

principal().catch(error => {
  term.grabInput(false);
  term.clear();
  console.error(error);
  process.exit(1);
});
